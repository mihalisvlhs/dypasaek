//
//  Massey University Screen Saver
//  Compile this using the makefile and copy massey.scr to your windows directory
//
#include <stdio.h>
#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>
#include <scrnsave.h>

struct colorIndexState {
   GLfloat amb[3];  /* ambient color / bottom of ramp */
   GLfloat diff[3]; /* diffuse color / middle of ramp */
   GLfloat spec[3]; /* specular color / top of ramp */
   GLfloat ratio;   /* ratio of diffuse to specular in ramp */
   GLint indexes[3];   /* where ramp was placed in palette */
};

#define NUM_COLORS (sizeof(colors) / sizeof(colors[0]))
struct colorIndexState colors[] = {
 { { 94.0F/255, 94.0F/255, 94.0F/255 }, { 1.0F, 1.0F, 1.0F }, { 1.0F, 1.0F, 1.0F },
      0.75F,{ 0, 0, 0 },
   }
   , { { 0.0F, 49.0/255, 94.0/255 }, {16.0/255, 143.0/255, 255.0/255}, { 225/255.0F, 241/255.0F, 1.0F },
      0.75F, { 0, 0, 0 },
   }
   ,
};

/* Windows globals, defines, and prototypes */
HGLRC hRC = (HGLRC) 0;
HDC hDC = (HDC) 0;
HDC hdc1;
HPALETTE hPalette = (HPALETTE) 0;
int nWndSize = 300;

// 5 vars(x,y,twist,lat,long) 3 derivs (fx,f'x,f''x) 3 values (val,max,min)
#define NVARS 5
#define NDERIV 4

int vars[NVARS][NDERIV][3]= { { {0,0,0}, {400,600, -600}, {-1,100,-100}, {0,0,0}
   }
   , { {0,0,0}, {200,600,-600}, {2,100,-100}, {0,0,0}
   }
   , { {36000,720000,-720000}, {100,500,-500}, {10,12,-12}, {1,1,-1}
   }
   , { {36000,720000,-720000}, {500,400,-400}, {8,10,-10}, {1,1,-1}
   }
   , { {36000,720000,-720000}, {500,600,-600}, {6,10,-10}, {1,1,-1}
   }
   ,
};

UINT nTimerID = 101;

#define PI 3.1415926
#define REFSPEED 50 // screen refresh speed (ms)
void setupPixelFormat(HDC);

//GLfloat  twist;
GLdouble radius;

GLvoid resize(GLsizei, GLsizei);
GLvoid initializeGL(GLsizei, GLsizei);
GLvoid drawScene(GLvoid);
void polarView( GLdouble, GLdouble, GLdouble, GLdouble);
void setupPalette(HDC hDC) {
   PIXELFORMATDESCRIPTOR pfd;
   LOGPALETTE* pPal;
   PALETTEENTRY *pe;
   int rampBase,pixelFormat,paletteSize,numRamps,rampSize,extra,diffSize,specSize;
   int i, r;
   
   pixelFormat=GetPixelFormat(hDC);
   DescribePixelFormat(hDC, pixelFormat, sizeof(PIXELFORMATDESCRIPTOR), &pfd);
   if (pfd.dwFlags & PFD_NEED_PALETTE ||
       pfd.iPixelType == PFD_TYPE_COLORINDEX) {
      paletteSize = 1 << pfd.cColorBits;
      if (paletteSize > 4096 || paletteSize==1) {
         paletteSize = 4096;
      }
   }
   else {
      return;
   }
   pPal = (LOGPALETTE*)
   malloc(sizeof(LOGPALETTE) + paletteSize * sizeof(PALETTEENTRY));
   pPal->palVersion = 0x300;
   pPal->palNumEntries = paletteSize;

   GetSystemPaletteEntries(hDC, 0, paletteSize, &pPal->palPalEntry[0]);
   numRamps = NUM_COLORS;
   rampSize = (paletteSize - 20) / numRamps;
   extra = (paletteSize - 20) - (numRamps * rampSize);

   for (r=0; r<numRamps; ++r) {
      rampBase = r * rampSize + 10;
      pe = &pPal->palPalEntry[rampBase];
      diffSize = (int) (rampSize * colors[r].ratio);
      specSize = rampSize - diffSize;

      for (i=0; i<rampSize; ++i) {
         GLfloat *c0, *c1;
         GLint a;

         if (i < diffSize) {
            c0 = colors[r].amb;
            c1 = colors[r].diff;
            a = (i * 255) / (diffSize - 1);
         }
         else {
            c0 = colors[r].diff;
            c1 = colors[r].spec;
            a = ((i - diffSize) * 255) / (specSize - 1);
         }

         pe[i].peRed = (BYTE) (a * (c1[0] - c0[0]) + 255 * c0[0]);
         pe[i].peGreen = (BYTE) (a * (c1[1] - c0[1]) + 255 * c0[1]);
         pe[i].peBlue = (BYTE) (a * (c1[2] - c0[2]) + 255 * c0[2]);
         pe[i].peFlags = PC_NOCOLLAPSE;
      }

      colors[r].indexes[0] = rampBase;
      colors[r].indexes[1] = rampBase + (diffSize-1);
      colors[r].indexes[2] = rampBase + (rampSize-1);
   }
   for (i=0; i<extra; ++i) {
      int index = numRamps*rampSize+10+i;
      PALETTEENTRY *pe = &pPal->palPalEntry[index];

      pe->peRed = (BYTE) 0;
      pe->peGreen = (BYTE) 0;
      pe->peBlue = (BYTE) 0;
      pe->peFlags = PC_NOCOLLAPSE;
   }


   hPalette = CreatePalette(pPal);
   free(pPal);

   if (hPalette) {
      SelectPalette(hDC, hPalette, FALSE);
      RealizePalette(hDC);
   }
}
static void initLights( void ) {  // initializes light and material properties

   GLfloat light_ambient[] = {1.0, 1.0, 1.0, 1.0};
   GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};
   GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};
   GLfloat light_position[] = {.7, .7, 1.25, 1.0};
   GLfloat mat_shininess[] = {30.0};

   glEnable(GL_LIGHTING);   // enables lighting
   glEnable(GL_LIGHT0);     // enables light source 0

   glLightModelfv(GL_LIGHT_MODEL_TWO_SIDE,(float[]){GL_FALSE});
   glLightfv(GL_LIGHT0, GL_AMBIENT,light_ambient);
   glLightfv(GL_LIGHT0, GL_DIFFUSE,light_diffuse);
   glLightfv(GL_LIGHT0, GL_SPECULAR,light_specular);
   glLightfv(GL_LIGHT0, GL_POSITION, light_position);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
}


LONG WINAPI ScreenSaverChildProc (HWND    hWnd,UINT    uMsg,WPARAM  wParam,LPARAM  lParam) {
   LONG    lRet = 1;
   PAINTSTRUCT    ps;
   RECT rect;

   switch (uMsg) {
      case WM_CREATE:
         hDC = GetDC(hWnd);
         setupPixelFormat(hDC);
         setupPalette(hDC);
         hRC = wglCreateContext(hDC);
         wglMakeCurrent(hDC, hRC);
         GetClientRect(hWnd, &rect);
         initializeGL(rect.right, rect.bottom);
         break;
      case WM_PAINT:
         BeginPaint(hWnd, &ps);
         drawScene();
         SwapBuffers(hDC);
         EndPaint(hWnd, &ps);
         break;
      case WM_SIZE:
         resize(LOWORD(lParam), HIWORD(lParam));
         break;
      case WM_PALETTECHANGED:
         if (hRC && hPalette && (HWND) wParam != hWnd) {
            UnrealizeObject(hPalette);
            SelectPalette(hDC, hPalette, FALSE);
            RealizePalette(hDC);
            return 0;
         }
         break;
      case WM_QUERYNEWPALETTE:
         if (hRC && hPalette) {
            UnrealizeObject(hPalette);
            SelectPalette(hDC, hPalette, FALSE);
            RealizePalette(hDC);
            return TRUE;
         }
         break;
      case WM_DESTROY:
         wglMakeCurrent(hDC, NULL);
         wglDeleteContext(hRC);
         ReleaseDC(hWnd,hDC);
         PostQuitMessage(0);
         break;
      case WM_ERASEBKGND:
         return 1;
         break;
      case WM_SYSCOMMAND:
      case WM_SETCURSOR:
      case WM_NCACTIVATE:
      case WM_ACTIVATE:
      case WM_ACTIVATEAPP:
      case WM_MOUSEMOVE:
      case WM_LBUTTONDOWN:
      case WM_MBUTTONDOWN:
      case WM_RBUTTONDOWN:
      case WM_KEYDOWN:
      case WM_SYSKEYDOWN:
         lRet = DefScreenSaverProc(hWnd, uMsg, wParam, lParam);
         DefScreenSaverProc(hMainWindow, uMsg, wParam, lParam);
         return lRet;

      default:
         lRet = DefWindowProc (hWnd, uMsg, wParam, lParam);
         break;
   }   return lRet;
}

LRESULT WINAPI ScreenSaverProc(HWND  hWnd,UINT  message, WPARAM  wParam, LPARAM  lParam) {
   static HWND hChild = NULL;
   HINSTANCE hInst = hMainInstance;
   WNDCLASS wc;

   int i,j,k;
   switch (message) {
      case WM_CREATE:
         wc.style                = CS_VREDRAW | CS_HREDRAW | CS_OWNDC ;
         wc.lpfnWndProc          = (WNDPROC) ScreenSaverChildProc;
         wc.cbClsExtra           = 0;
         wc.cbWndExtra           = 0;
         wc.hInstance            = hInst;
         wc.hIcon                = NULL;
         wc.hCursor              = NULL;
         wc.hbrBackground        = NULL;
         wc.lpszMenuName         = NULL;
         wc.lpszClassName        = "NTDEVCLASS";
         RegisterClass(&wc);
         if(vars[0][0][1]==0) {
            RECT rect;
            GetClientRect(hWnd,&rect);
            hdc1 = GetDC(hWnd);
            setupPixelFormat(hdc1);
            setupPalette(hdc1);
            nWndSize = rect.right/3;
            vars[0][0][1] = (rect.right-nWndSize)*100;
            vars[1][0][1] = (rect.bottom-nWndSize)*100;
            vars[0][0][2] = 0;//(-nWndSize/2)*100;
            vars[1][0][2] = 0;//(-nWndSize/2)*100;
         }
         hChild = CreateWindow(wc.lpszClassName,"Child1",WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
                               0, 0,nWndSize, nWndSize, hWnd, NULL,hInst,NULL);
         SetTimer(hWnd, nTimerID,REFSPEED,NULL);
         break;     
      case WM_PALETTECHANGED:
         if (hRC && hPalette && (HWND) wParam != hWnd) {
            UnrealizeObject(hPalette);
            SelectPalette(hdc1, hPalette, FALSE);
            RealizePalette(hdc1);
            return 0;
         }
         break;
      case WM_QUERYNEWPALETTE:
         if (hRC && hPalette) {
            UnrealizeObject(hPalette);
            SelectPalette(hdc1, hPalette, FALSE);
            RealizePalette(hdc1);
            return TRUE;
         }
         break;
      case WM_DESTROY:
         KillTimer(hWnd, nTimerID);
         DestroyWindow(hChild);
         PostQuitMessage(0);
         break;
      case WM_TIMER:
         for(i=0;i<NVARS;i++)
            for(j=NDERIV-2;j>=0;j--) {
              vars[i][j][0]+=vars[i][j+1][0];
              if (vars[i][j][0]>vars[i][j][1]) {
                 if(j==-1)
                    vars[i][j][0]=vars[i][j][2];
                 else {
	                 vars[i][j][0]=vars[i][j][1];
	                 for(k=j+1;k<NDERIV;k++)
	                    vars[i][k][0]=-vars[i][k][0];
                 }
              }
              if (vars[i][j][0]<vars[i][j][2]) {
                 if(j==-1)
                    vars[i][j][0]=vars[i][j][1];
                 else {
	                 vars[i][j][0]=vars[i][j][2];
	                 for(k=j+1;k<NDERIV;k++)
	                    vars[i][k][0]=-vars[i][k][0];
                 }
              }
            }
         MoveWindow(hChild,vars[0][0][0]/100,vars[1][0][0]/100, nWndSize, nWndSize, FALSE);
         InvalidateRect(hChild, NULL, FALSE);
         break;
      default:
         return DefScreenSaverProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

void setupPixelFormat(HDC hDC) {
   PIXELFORMATDESCRIPTOR pfd = {
      sizeof(PIXELFORMATDESCRIPTOR),1,PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER,
      PFD_TYPE_COLORINDEX,8,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,PFD_MAIN_PLANE,0,0,0,0
   };
   int SelectedPixelFormat;
   BOOL retVal;

   SelectedPixelFormat = ChoosePixelFormat(hDC, &pfd);
   if (SelectedPixelFormat == 0)
      exit(1);
   retVal = SetPixelFormat(hDC, SelectedPixelFormat, &pfd);
   if (retVal != TRUE)
      exit(1);
}



GLvoid resize( GLsizei width, GLsizei height ) {
   GLfloat aspect;

   glViewport( 0, 0, width, height );
   aspect = (GLfloat) width / height;
   glMatrixMode( GL_PROJECTION );
   glLoadIdentity();
   gluPerspective( 24.0, aspect, 3.0, 7.0 );
   glMatrixMode( GL_MODELVIEW );
}

double dist(double a,double b,double c) {
   return sqrt(a*a+b*b+c*c);
}

GLvoid createObjects() {
   int i;
   const int w=20;
   const int pts=13;
   double sq[][3]= { {100,100,0}, {100-w,100,0}, {-100+w,100,0}, {-100,100,0}, {-100,100-w,0}, {-100,-100+w,0}, {-100,-100,0}, {-100+w,-100,0}, {100-w,-100,0}, {100,-100,0}, {100,-100+w,0}, {100,100-w,0}, {100,100,0}
   };
   double sq1[pts][3];
   double sq2[pts][3];
   double n[pts][3];
   double x1;
   double sum;
   double th,x,th1,xx,yy,y,z;
   int j;
   const int steps=72;

   glNewList(1, GL_COMPILE);
   glShadeModel(GL_FLAT);
   for(i=0;i<steps+1;i++) {
      th=(i*360.0/steps)*(2*PI)/360.0;
      xx=cos(th);
      yy=sin(th);
      th1=-(i/(steps/3.0))*(PI/2);
      for(j=0;j<pts;j++) {
         x=sq[j][0];
         y=sq[j][1];
         z=sq[j][2];
         x1=cos(th1)*x-sin(th1)*y;
         y=cos(th1)*y+sin(th1)*x;
         x=x1+300;
         n[j][0]=xx*x1-yy*z;
         n[j][2]=y;
         n[j][1]=xx*z+yy*x1;
         sq1[j][0]=(xx*x-yy*z)/600;
         sq1[j][2]=y/600;
         sq1[j][1]=(xx*z+yy*x)/600;
      }
      glBegin(GL_QUAD_STRIP);
      if(i!=0)
         for (j=0; j<pts; j++) {
            if(((j+1)%3)==0 && !((j<pts-1) && (i%3==0) && (((j*4)/(pts-1))==i/(steps/3) ||
              ((((j*4)/(pts-1))+2)%4)==i/(steps/3))))
            	glMaterialiv(GL_FRONT, GL_COLOR_INDEXES, colors[1].indexes);
            else
               glMaterialiv(GL_FRONT, GL_COLOR_INDEXES, colors[0].indexes);
            sum=dist(n[j][0], n[j][1], n[j][2]);
            glNormal3f(n[j][0]/sum, n[j][1]/sum, n[j][2]/sum);
            glVertex3f(sq1[j][0], sq1[j][1], sq1[j][2]);
            glVertex3f(sq2[j][0], sq2[j][1], sq2[j][2]);
         }
      glEnd();
      for(j=0;j<pts;j++)
         for(int k=0;k<3;k++)
            sq2[j][k]=sq1[j][k];
   }
   glEndList();
}

GLvoid initializeGL(GLsizei width, GLsizei height) {
   GLfloat     maxObjectSize, aspect;
   GLdouble    near_plane, far_plane;

   glClearColor(0,0,0,0);
 
   glEnable(GL_DEPTH_TEST);
   glMatrixMode( GL_PROJECTION );
   aspect = (GLfloat) width / height;
   gluPerspective( 45.0, aspect, 3.0, 7.0 );
   glMatrixMode( GL_MODELVIEW );
   near_plane = 3.0;
   far_plane = 7.0;
   maxObjectSize = 3.0F;
   radius = near_plane + maxObjectSize/2.0;
   createObjects();
   initLights();
}

void polarView(GLdouble radius, GLdouble twist, GLdouble latitude, GLdouble longitude) {
   glTranslated(0.0, 0.0, -radius);
   glRotated(-twist, 0.0, 0.0, 1.0);
   glRotated(-latitude, 1.0, 0.0, 0.0);
   glRotated(longitude, 0.0, 0.0, 1.0);
}


GLvoid drawScene(GLvoid) {
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
   glPushMatrix();
   polarView( radius, (float)vars[2][0][0]/100.0, (float)vars[3][0][0]/100.0, (float)vars[4][0][0]/100.0 );
   glCallList(1);
   glPopMatrix();
}

BOOL WINAPI ScreenSaverConfigureDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
   switch (message) {
      case WM_INITDIALOG:
      return TRUE;
      break;
      case WM_COMMAND:
      switch (LOWORD(wParam)) {
         case IDOK:
         EndDialog(hDlg, TRUE);
         break;
         default:
         break;
      }
      return TRUE;
      break;
      default:
      return 0;
      break;
   }
   return 0;
}


BOOL WINAPI RegisterDialogClasses(HANDLE hInst) {
   return TRUE;
}


