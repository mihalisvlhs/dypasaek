#ifndef _ISGUID_H
#define _ISGUID_H
extern const GUID CLSID_InternetShortcut;
extern const GUID IID_IUniformResourceLocator;
#endif
